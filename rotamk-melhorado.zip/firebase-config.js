// Cole aqui a configuração do seu projeto Firebase (veja CONFIGURAR-NUVEM.md).
// Enquanto estiver null, o app funciona normalmente, só que salvando apenas no celular.
window.FIREBASE_CONFIG = null;
/* Exemplo:
window.FIREBASE_CONFIG = {
  apiKey: "AIza...",
  authDomain: "rotamk-xxxx.firebaseapp.com",
  projectId: "rotamk-xxxx",
  appId: "1:123:web:abc"
};
*/

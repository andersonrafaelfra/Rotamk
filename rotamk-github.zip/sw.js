const C='rotamk-v3';
const FILES=['./','index.html','manifest.webmanifest','leaflet.js','leaflet.css','xlsx.full.min.js','html5-qrcode.min.js','icon-192.png','icon-512.png','firebase-config.js','firebase.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(FILES)));self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))));self.clients.claim();});
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(e.request.method!=='GET') return;
  if(u.origin===location.origin){ // app: rede primeiro (pega atualização), cache se offline
    e.respondWith(fetch(e.request).then(r=>{const cp=r.clone();caches.open(C).then(c=>c.put(e.request,cp));return r;}).catch(()=>caches.match(e.request)));
  } else if(u.hostname.endsWith('tile.openstreetmap.org')){ // mapa: cache primeiro
    e.respondWith(caches.match(e.request).then(m=>m||fetch(e.request).then(r=>{const cp=r.clone();caches.open(C+'-tiles').then(c=>c.put(e.request,cp));return r;})));
  }
});
